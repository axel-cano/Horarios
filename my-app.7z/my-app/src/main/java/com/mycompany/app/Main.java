package com.mycompany.app;


import org.orzhov.Main.App;
/**
 * Hello world!
 *
 */
public class Main 
{
    public static void main( String[] args )
    {
        App.main(args);
    }
}
